import { test, expect } from '@playwright/test';

test.describe('Create Lead in Leaftaps Application', () => {

  test('Verify user can create a new lead successfully', async ({ page }) => {
    // When I enter Username as "Democsr2"
    await page.getByLabel('Username').fill('Democsr2');
    // And I enter Password as "crmsfa"
    await page.getByLabel('Password').fill('crmsfa');
    // And I click the login button
    await page.getByRole('button', { name: 'Login' }).click();
    // When I click on the "CRM/SFA" link
    await page.getByRole('link', { name: 'CRM/SFA' }).click();
    // And I click on the "Leads" tab
    await page.getByRole('link', { name: 'Leads' }).click();
    // And I click on the "Create Lead" link
    await page.getByRole('link', { name: 'Create Lead' }).click();
  });
});
