import { test, expect } from '@playwright/test';

test.describe('Sample Login Test', () => {

  test('Successful login with valid credentials', async ({ page }) => {
    // Given I navigate to "https://example.com/login"
    await page.goto('https://example.com/login');
  });

  test('Failed login with invalid credentials', async ({ page }) => {
    // Given I navigate to "https://example.com/login"
    await page.goto('https://example.com/login');
  });
});
