import { test, expect } from '@playwright/test';

test.describe('Contact Us Form', () => {

  test('Verify user can submit the Contact Us form', async ({ page }) => {
    // When I click on the "Contact us" menu
    await page.getByRole('link', { name: ' Contact us' }).click();
    // And I enter the Name as "Sankar"
    await page.getByLabel('Name').fill('Sankar');
    // And I enter the Email as "sankar@test.com"
    await page.getByLabel('Email').fill('sankar@test.com');
    // And I enter the Subject as "Automation Testing"
    await page.getByLabel('Subject').fill('Automation Testing');
    // And I enter the Message as "This is a sample message."
    await page.getByLabel('Your Message Here').fill('This is a sample message.');
    // And I click the Submit button
    await page.getByRole('button', { name: 'Submit' }).click();
  });
});
