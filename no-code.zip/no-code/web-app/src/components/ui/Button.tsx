/**
 * Button Component
 * Reusable button with accessible color variants, sizes and icon support.
 */

import { forwardRef } from 'react';
import type { ButtonHTMLAttributes, ReactNode } from 'react';
import type { LucideIcon } from 'lucide-react';
import { Loader2 } from 'lucide-react';
import { cn } from '@/utils';

export type ButtonVariant =
  | 'primary'
  | 'secondary'
  | 'outline'
  | 'ghost'
  | 'destructive'
  | 'success';

export type ButtonSize = 'sm' | 'md' | 'lg' | 'icon';

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  /** Visual style */
  variant?: ButtonVariant;
  /** Size preset */
  size?: ButtonSize;
  /** Icon shown before the label */
  leftIcon?: LucideIcon;
  /** Icon shown after the label */
  rightIcon?: LucideIcon;
  /** Show a loading spinner and disable the button */
  isLoading?: boolean;
  /** Button contents */
  children?: ReactNode;
}

/**
 * Variant styles — each pairs a background with a foreground that meets
 * contrast requirements, plus a clear hover and focus state.
 */
const variantClasses: Record<ButtonVariant, string> = {
  primary:
    'bg-primary text-primary-foreground shadow-sm hover:bg-primary/90 focus-visible:ring-ring',
  secondary:
    'bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80 focus-visible:ring-ring',
  outline:
    'border border-input bg-background text-foreground shadow-sm hover:bg-muted hover:text-foreground focus-visible:ring-ring',
  ghost:
    'text-muted-foreground hover:bg-muted hover:text-foreground focus-visible:ring-ring',
  destructive:
    'bg-red-600 text-white shadow-sm hover:bg-red-700 focus-visible:ring-red-500',
  success:
    'bg-green-600 text-white shadow-sm hover:bg-green-700 focus-visible:ring-green-500',
};

const sizeClasses: Record<ButtonSize, string> = {
  sm: 'h-8 gap-1.5 px-3 text-xs',
  md: 'h-10 gap-2 px-4 text-sm',
  lg: 'h-11 gap-2 px-6 text-base',
  icon: 'h-10 w-10 justify-center',
};

const iconSizeClasses: Record<ButtonSize, string> = {
  sm: 'h-3.5 w-3.5',
  md: 'h-4 w-4',
  lg: 'h-5 w-5',
  icon: 'h-4 w-4',
};

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      variant = 'primary',
      size = 'md',
      leftIcon: LeftIcon,
      rightIcon: RightIcon,
      isLoading = false,
      disabled,
      className,
      children,
      ...props
    },
    ref
  ) => {
    const iconSize = iconSizeClasses[size];

    return (
      <button
        ref={ref}
        disabled={disabled || isLoading}
        className={cn(
          'inline-flex items-center justify-center rounded-md font-medium transition-colors',
          'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-offset-background',
          'disabled:pointer-events-none disabled:opacity-50',
          variantClasses[variant],
          sizeClasses[size],
          className
        )}
        {...props}
      >
        {isLoading ? (
          <Loader2 className={cn(iconSize, 'animate-spin')} />
        ) : (
          LeftIcon && <LeftIcon className={iconSize} />
        )}
        {children}
        {!isLoading && RightIcon && <RightIcon className={iconSize} />}
      </button>
    );
  }
);

Button.displayName = 'Button';

export default Button;
