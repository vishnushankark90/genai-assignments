/**
 * Logo Component
 * TestLeaf brand logo with optional platform text
 */

import { cn } from '@/utils';

export interface LogoProps {
  /** Show text next to logo */
  showText?: boolean;
  /** Size variant */
  size?: 'sm' | 'md' | 'lg';
  /** Additional CSS classes */
  className?: string;
}

const sizeConfig = {
  sm: {
    img: 'h-6',
    mark: 'h-6 w-6',
    title: 'text-sm',
    subtitle: 'text-[10px]',
  },
  md: {
    img: 'h-8',
    mark: 'h-8 w-8',
    title: 'text-base',
    subtitle: 'text-xs',
  },
  lg: {
    img: 'h-10',
    mark: 'h-10 w-10',
    title: 'text-xl',
    subtitle: 'text-sm',
  },
};

const LOGO_SRC = '/testleaf-logo-white.webp';

export function Logo({ showText = true, size = 'md', className }: LogoProps) {
  const config = sizeConfig[size];

  // Collapsed / icon-only mode: show a compact, cropped mark of the logo.
  if (!showText) {
    return (
      <div className={cn('flex items-center justify-center', className)}>
        <img
          src={LOGO_SRC}
          alt="TestLeaf"
          className={cn(
            'w-auto object-contain',
            config.mark,
            // White logo -> invert to dark on light theme, keep white on dark theme
            'invert dark:invert-0'
          )}
        />
      </div>
    );
  }

  return (
    <div className={cn('flex items-center gap-2.5', className)}>
      <img
        src={LOGO_SRC}
        alt="TestLeaf"
        className={cn(
          'block w-auto shrink-0 object-contain',
          config.img,
          'invert dark:invert-0'
        )}
      />

      {/* Divider */}
      <span className={cn('w-px shrink-0 bg-border', config.img)} aria-hidden="true" />

      {/* Platform Text */}
      <div className="flex flex-col justify-center">
        <span className={cn('font-bold leading-none text-foreground', config.title)}>
          No-Code
        </span>
        <span className={cn('mt-0.5 leading-none text-muted-foreground', config.subtitle)}>
          Automation Platform
        </span>
      </div>
    </div>
  );
}

export default Logo;
